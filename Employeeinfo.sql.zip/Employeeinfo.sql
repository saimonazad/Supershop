
CREATE TABLE "Employeeinfo" ("employeeid" INTEGER PRIMARY KEY  NOT NULL  DEFAULT (1) ,"name" CHAR,"surname" CHAR,"age" INTEGER,"password" CHAR, "username" CHAR);
INSERT INTO "Employeeinfo" VALUES(1,'saimon','azad',22,'root','root');
